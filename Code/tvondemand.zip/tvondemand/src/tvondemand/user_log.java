/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tvondemand;

/**
 *
 * @author Giannis
 */
public class user_log{
private static String log_user_email;
private static String log_user_id;
public static String get_email(){
return user_log.log_user_email;}
public static String get_id(){
return user_log.log_user_id;}
public static void setEmail(String var){
user_log.log_user_email=var;
}
public static void set_id(String var){
user_log.log_user_id=var;}
}